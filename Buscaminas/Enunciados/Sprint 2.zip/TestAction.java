package uo.mp.minesweeper.game.square;

import uo.mp.minesweeper.game.square.action.Action;


class TestAction implements Action {
	boolean executed = false;
	
	@Override 
	public boolean execute() {
		executed = true;
		return true;
	}
}
