package uo.mp.minesweeper.util.log;

public interface SimpleLogger {
	void log(Exception ex);
}
